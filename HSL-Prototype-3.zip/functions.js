$(".duchifat-1").hover(
    function(){
        $(".duchifat-1").addClass("hover");
    }, function(){
        $(".duchifat-1").removeClass("hover");
    }
);